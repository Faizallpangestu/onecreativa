<?php
$DB_HOST = 'localhost';
$DB_USER = 'u260890310_one';
$DB_PASS = 'Creativa4321!';
$DB_NAME = 'u260890310_one';
